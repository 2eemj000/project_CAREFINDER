package edu.pnu.config;

import java.util.Map;

import javax.swing.Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;


import edu.pnu.domain.Member;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Configuration
@EnableWebSecurity
public class SecurityConfig  {
	@Autowired
    private CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		
		 http
	        // CSRF 보호 비활성화 (API 사용 시 CSRF를 비활성화하는 경우)
	        .csrf(csrf -> csrf.disable())
	        
	        // CORS 설정
	        .cors(cors -> cors.configurationSource(corsSource()))
	        
	        // 로그인 설정
	        .formLogin(form -> form
	            .loginPage("http://localhost:3000/community") // 로그인 페이지 URL
	            .defaultSuccessUrl("http://localhost:3000/community", true) // 로그인 성공 후 리다이렉트 URL
	            .permitAll() // 로그인 페이지 접근 허용
	        )
	        
	        .oauth2Login(oauth2->oauth2
					 //.loginPage("http://localhost:8080/oauth2/authorization/google")
	        			.userInfoEndpoint(userInfo -> userInfo
	                        .userService(customOAuth2UserService()) // 여기에서 CustomOAuth2UserService를 설정
	                    )
	        			.successHandler( customAuthenticationSuccessHandler)
					 .defaultSuccessUrl("http://localhost:3000/community", true)
					 )
	        // 로그아웃 설정
	        .logout(logout -> logout
	            .invalidateHttpSession(true)
	            .deleteCookies("JSESSIONID")
	            .logoutSuccessUrl("http://localhost:3000/find")
	        )
	        
	        // 세션 관리 설정
	        .sessionManagement(sessionManagement -> sessionManagement
	            .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED) // 세션이 필요할 때만 생성
	            .maximumSessions(1) // 동시에 허용되는 최대 세션 수
	            .expiredUrl("http://localhost:3000/find") // 세션 만료 시 URL
	        )
	        
	        // 요청 권한 설정
	        .authorizeHttpRequests(authorize -> authorize
	            .requestMatchers("http://localhost:8080/community/write","/auth/status").authenticated() // /write 경로는 인증된 사용자만 접근 가능
	          
	            .anyRequest().permitAll() // 나머지 요청은 모두 허용
	        )
	        
	        ;
		 
 
		 return http.build();
		 
		 
		 
		 
  
	}
	@Bean
	  OAuth2UserService<OAuth2UserRequest, OAuth2User> customOAuth2UserService() {
		// TODO Auto-generated method stub
		 return new CustomOAuth2UserService();
	}
	
	
	
	
	private CorsConfigurationSource corsSource() {
		 CorsConfiguration config = new CorsConfiguration();
		 config.addAllowedOriginPattern(CorsConfiguration.ALL) ;
		 config.addAllowedMethod(CorsConfiguration.ALL) ;
		 config.addAllowedHeader(CorsConfiguration.ALL);
		 config.setAllowCredentials(true);
		 // 요청을 허용할 서버
		// 요청을 허용할 Method
		 // 요청을 허용할 Header
		 // 요청/응답에 자격증명정보 포함을 허용
	
		// true인 경우 addAllowedOrigin(“*”)는 사용 불가 ➔ Pattern으로 변경
		 config.addExposedHeader(CorsConfiguration.ALL);
		 // Header에 Authorization을 추가하기 위해서는 필요
		 UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		 source.registerCorsConfiguration("/**", config);
		 return source;
		 }
	 
	@Bean
	PasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}

}