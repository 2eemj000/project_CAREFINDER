package edu.pnu.config;

import java.io.IOException;
import java.net.URLEncoder;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        // 구글 로그인 후 쿠키 설정
        Cookie googleLoginCookie = new Cookie("googleLoggedIn", "true");
        googleLoginCookie.setPath("/");
        googleLoginCookie.setHttpOnly(true);
        googleLoginCookie.setMaxAge(24 * 60 * 60); // 1일 동안 유효

        response.addCookie(googleLoginCookie);

     
    }
}


