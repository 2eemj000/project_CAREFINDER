package edu.pnu.domain;





import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity

@Table(name = "member")
public class Member {
	@Id
	@Column(name="username")
	private String username;
    @Column(name = "password")
	private String password;
    @Column(name = "role")
	private String role;
    @Column(name = "email", nullable = false)
	private String email;
	
    
    public void setEmail(String email) {
        if (email == null || email.isEmpty()) {
            throw new IllegalArgumentException("Email cannot be null or empty");
        }
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
	
}



