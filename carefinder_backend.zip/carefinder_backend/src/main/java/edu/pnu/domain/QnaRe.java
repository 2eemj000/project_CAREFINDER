package edu.pnu.domain;

import java.util.Date;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "qna_re")

public class QnaRe {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="qnare_id" )
	private Long qnaReId;
	private String content;
	@Temporal(value=TemporalType.TIMESTAMP)
	@Column(name="create_date" )
	private Date createDate;

	@ManyToOne
	@JoinColumn(name="username" , referencedColumnName = "username",  nullable=false)
	private Member member;
	@ManyToOne
	@JoinColumn(name="qna_id" , referencedColumnName = "qna_id",  nullable=false)
	private Qna qna;
	
}





