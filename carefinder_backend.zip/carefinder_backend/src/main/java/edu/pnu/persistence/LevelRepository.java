package edu.pnu.persistence;




import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Board;
import edu.pnu.domain.Doctor;
import edu.pnu.domain.Level;

public interface LevelRepository extends JpaRepository<Level, Long>{
	

	
	@Query("SELECT i FROM Level i WHERE i.information.hospitalCode = ?1")
	public Level getHospitalListFromLevel(String code);
	
	
	
}
