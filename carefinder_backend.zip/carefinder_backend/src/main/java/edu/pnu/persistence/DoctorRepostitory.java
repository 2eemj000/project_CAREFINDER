package edu.pnu.persistence;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Board;
import edu.pnu.domain.Doctor;


public interface DoctorRepostitory extends JpaRepository<Doctor, Long>{
	
	

	// 모든 doctor를 검색하며, 특정 hospitalCode와 일치하는 레코드를 반환
	@Query("SELECT d.information.hospitalCode FROM Doctor d WHERE d.information.hospitalCode = ?2 AND d.doctor LIKE %?1%")
	public String findHospitalCodesByDoctor(String doctor, String hospitalCode);

	// '정형외과'
	@Query("SELECT d.information.hospitalCode FROM Doctor d WHERE d.information.hospitalCode = ?2 AND d.doctor LIKE %?1% ")
	public String findHospitalCodesByDoctorExcludingOrthopedics(String doctor, String hospitalCode);

	
	
	@Query("SELECT d.doctor FROM Doctor d WHERE d.information.hospitalCode=?1 ")
	public String getDoctor(String cardId) ;
	

	
	
	
	
}
