package edu.pnu.persistence;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Board;
import edu.pnu.domain.Information;

public interface InformationRepostitory extends JpaRepository<Information, Long>{
	@Query("select i.hospitalCode from Information i where i.sidoCodeName=?1 and i.sigunguCodeName=?2")
	List<String> getCodeList(String finalSido,String finalSigungu);
	
	
	@Query("select i from Information i where i.hospitalCode=?1")
	Information  getAllInfo( String cardId) ;
}
