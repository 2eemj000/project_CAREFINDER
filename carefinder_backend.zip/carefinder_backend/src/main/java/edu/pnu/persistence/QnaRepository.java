package edu.pnu.persistence;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Qna;

public interface QnaRepository extends JpaRepository<Qna, Long>{
	
	@Query("select b from Qna b where b.member.username=?1")
	public List<Object> getMyQna(String username);

}
