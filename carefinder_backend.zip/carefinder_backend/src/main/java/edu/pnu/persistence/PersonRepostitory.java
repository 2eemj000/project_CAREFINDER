package edu.pnu.persistence;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Board;
import edu.pnu.domain.Doctor;
import edu.pnu.domain.Person;

public interface PersonRepostitory extends JpaRepository<Person, Long>{

	
	
	@Query("SELECT d.information.hospitalCode FROM Person d WHERE d.information.hospitalCode=?2 and d.person like %?1%")
	 public String gethospitalListtFromPerson(String d, String c) ;
	
	@Query("SELECT d.person FROM Person d WHERE d.information.hospitalCode=?1 ")
	public String getPerson(String cardId) ;

}
