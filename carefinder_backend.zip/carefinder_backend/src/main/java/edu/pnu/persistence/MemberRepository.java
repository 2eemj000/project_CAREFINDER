package edu.pnu.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Member;

public interface MemberRepository extends JpaRepository <Member, String>{
//	Member findByUsername(String username);
	Member findByUsernameAndPassword(String username, String password);
	Member findByEmail(String email);
	
	
	@Query("select m from Member m where m.email = ?1")
	Member checkEmailExists(String email);
	
	@Query("select m from Member m where m.username = ?1")
	Member checkUsernameExists(String username);
}
