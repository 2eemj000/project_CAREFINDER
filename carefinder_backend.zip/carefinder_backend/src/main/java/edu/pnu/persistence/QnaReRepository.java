package edu.pnu.persistence;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import edu.pnu.domain.QnaRe;

public interface QnaReRepository extends JpaRepository<QnaRe, Long>{
	@Query("select b from QnaRe b where b.qna.qnaId=?1")
	public List<QnaRe> findQnaRe(Long id);
	
	@Modifying
	@Query("delete  from  QnaRe b where b.qna.qnaId=?1")
	public void deleteByQnaId(Long qnaId);
}
