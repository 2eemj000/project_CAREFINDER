package edu.pnu.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Board;
import edu.pnu.domain.BoardRe;
import edu.pnu.domain.Favorites;

public interface FavoriteRepository extends JpaRepository<Favorites, Long>{
	@Query("select f.hospitalCode from Favorites f where f.username =?1")
	List<String> findByUserId(String username);
	
	
	@Modifying
	@Query("delete  from Favorites f where f.username =?1 and f.hospitalCode =?2")
	void deleteByUsernameAndHospitalCode(String username, String hospitalCode);
	
}
