package edu.pnu.persistence;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Sidosigungu;

public interface SidosigunguRepository extends JpaRepository<Sidosigungu, Long>{
	@Query("SELECT  MIN(s.sidoId),s.sidoname FROM Sidosigungu s GROUP BY s.sidoname")
	public  List<String[]> findRegions();
	
	
	@Query("SELECT s.sidoId, s.sigunguname FROM Sidosigungu s WHERE s.sidoname = ?1 ORDER BY s.sidoId ASC")
	public  List<String[]> findSubRegions(String region1);
	
	@Query("select s from Sidosigungu s where s.sidoId=?1 ")
	public  Sidosigungu findSubRegionsCode(String region1);
	
	@Query("select s.sidoname from Sidosigungu s where s.sidoId=?1")
	public String findByfinalSido(String sido);
	
	@Query("select s.sigunguname from Sidosigungu s where s.sidoId=?1")
	public String findByfinalSigungu(String sido);
}
