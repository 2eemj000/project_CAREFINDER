package edu.pnu.service;



import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.pnu.domain.Doctor;
import edu.pnu.domain.Information;
import edu.pnu.domain.Level;
import edu.pnu.domain.Person;
import edu.pnu.domain.Sidosigungu;
import edu.pnu.persistence.DoctorRepostitory;
import edu.pnu.persistence.InformationRepostitory;
import edu.pnu.persistence.LevelRepository;
import edu.pnu.persistence.PersonRepostitory;
import edu.pnu.persistence.SidosigunguRepository;



@Service
public class InformationService {
	@Autowired
	private InformationRepostitory informationRepo;
	
	@Autowired
	private DoctorRepostitory doctorRepo;
	
	
	@Autowired
	private PersonRepostitory personRepo;
	
	@Autowired
	private LevelRepository levelRepo;
	
	@Autowired
	private SidosigunguRepository sidosigunguRepo;
	
	
	@Transactional
    public List<String> getCodeList(String finalSido,String finalSigungu) {
        return informationRepo.getCodeList(finalSido, finalSigungu);
    }
	
	@Transactional
    public String getlocation(String sido) {
        return sidosigunguRepo.findByfinalSido(sido);
    }
	
	
	@Transactional
    public String getlocation2(String sido) {
		
        return sidosigunguRepo.findByfinalSigungu(sido);
    }
	
//	@Transactional
//    public List<String>  gethospitalListtFromDoctor( List <String> codeList,List<String> doctor) {
//		 
//		  	Set<String> dlist = new HashSet<>();
//		  	if (doctor.contains("외과")) {
//		  		 // 데이터 처리
//		        for (String d : doctor) {
//		            for (String c : codeList) {
//		                Doctor tmp = doctorRepo.gethospitalListtFromDoctor1(d, c);
//		                System.out.println(tmp);
//		                if (tmp != null) {
//		                    dlist.add(c); // 중복 검사 없이 바로 추가
//		                }
//		            }
//		        }
//		  	}else if (doctor.contains("정형외과")) {
//		  		 // 데이터 처리
//		        for (String d : doctor) {
//		            for (String c : codeList) {
//		                Doctor tmp = doctorRepo.gethospitalListtFromDoctor2(d, c);
//		                System.out.println(tmp);
//		                if (tmp != null) {
//		                    dlist.add(c); // 중복 검사 없이 바로 추가
//		                }
//		            }
//		        }
//		  	}
//		  	
//		  	
//		  	else {
//		  		 // 데이터 처리
//		        for (String d : doctor) {
//		            for (String c : codeList) {
//		                Doctor tmp = doctorRepo.gethospitalListtFromDoctor(d, c);
//		                System.out.println(tmp);
//		                if (tmp != null) {
//		                    dlist.add(c); // 중복 검사 없이 바로 추가
//		                }
//		            }
//		        }
//		  	}
//		  	
//	       
//	        List<String>  finaldlist=new ArrayList<>(dlist);
//	        System.out.println("Resulting list: " + new ArrayList<>(dlist));
//	        return   finaldlist;
//    }
	@Transactional
	public List<String> gethospitalListtFromDoctor(List<String> codeList, List<String> doctor) {

	    List<List<String>> ForintersectionList = new ArrayList<>();
	  
	   
	    	

		        for (String  d : doctor) {
		        	List<String> list1=  new ArrayList<>();
		        	if (d.equals("외과")) {
		        		
		        		List<String> subject_doc=  new ArrayList<>();
		        		List<String> subject_Borndoc=  new ArrayList<>();
		        		
		        		for (String c : codeList) {
		        				String tmpList = doctorRepo.findHospitalCodesByDoctor("외과", c);
		        				String tmpList2 = doctorRepo.findHospitalCodesByDoctor("정형외과", c);
		        				
		        				if (tmpList !=null) subject_doc.add(tmpList);
		        				if (tmpList2 !=null)subject_Borndoc.add(tmpList2);
		        			}
		        			// 리스트를 Set으로 변환
		        		Set<String> set1 = new HashSet<>(subject_doc);
		        		Set<String> set2 = new HashSet<>(subject_Borndoc);

			            // 차집합 계산: set1에서 set2를 제외
		        		set1.removeAll(set2);
		        		list1.addAll(set1);
		        		
		        		
		        	}
		        	else {
		        		
			        	for (String c : codeList) {
			        		String tmpList = doctorRepo.findHospitalCodesByDoctor(d, c);
			        		System.out.println("doctor" +d +"code" +c+ "추출한 코드"+tmpList);
			        		if (tmpList != null ) {
			        			list1.add(tmpList); // 결과를 Set에 추가하여 중복 제거
			        		}
			        		  
			        	}
		        	}
		        	ForintersectionList.add(new ArrayList<>(list1));
		        	System.out.println("list1" +list1);
		        	list1.clear();
		        }
		        
	    
	    	
		      Set<String> intersection = getIntersection(ForintersectionList);
		      List<String> finaldlist = new ArrayList<>(intersection);
		      return finaldlist;
	}

	@Transactional
    public List<String>  gethospitalListtFromPerson( List <String> codeList,List<String>person) {
		List<List<String>> ForintersectionList = new ArrayList<>();
        for (String p : person) {
        	List<String> list1=  new ArrayList<>();

        	for (String c : codeList) {
        		String tmpList = personRepo.gethospitalListtFromPerson(p, c);
        		
        		if (tmpList != null ) {
        			list1.add(tmpList); // 결과를 Set에 추가하여 중복 제거
        		}
        		  
        	}
        	ForintersectionList.add(new ArrayList<>(list1));
        	System.out.println("list1" +list1);
        	list1.clear();
    	}
    	
    
    
    	Set<String> intersection = getIntersection(ForintersectionList);
    	List<String> finaldlist = new ArrayList<>(intersection);
    	return finaldlist;
	}

	@Transactional
	public Level getHospitalListFromLevel(String code) {
		

	    return levelRepo.getHospitalListFromLevel(code); // List<Level>을 직접 반환
	}
	
	
	


    public  List<String[]> getLocation() {
	
		return sidosigunguRepo.findRegions();
    }
    
    public  List<String[]> getLocation( String region1) {
    	
    		return sidosigunguRepo.findSubRegions(region1);
        }
    
    public Sidosigungu findSubRegionsCode( String region1) {
    	
		return sidosigunguRepo.findSubRegionsCode(region1);
    }
	
    
    public String getDoctor( String cardId) {
    	
		return doctorRepo.getDoctor(cardId);
    }
    public String getPerson( String cardId) {
    	
		return personRepo.getPerson(cardId);
    }
    public Information  getAllInfo( String cardId) {
 	
		return informationRepo.getAllInfo(cardId);
    }
    
    
    public static Set<String> getIntersection(List<List<String>> lists) {
        if (lists == null || lists.isEmpty()) {
            return new HashSet<>();
        }

        // 첫 번째 리스트의 모든 요소를 포함하는 set을 생성
        Set<String> intersection = new HashSet<>(lists.get(0));

        // 나머지 리스트들과 교집합을 구함
        for (List<String> list : lists.subList(1, lists.size())) {
            intersection.retainAll(list);
        }

        return intersection;
    }
}