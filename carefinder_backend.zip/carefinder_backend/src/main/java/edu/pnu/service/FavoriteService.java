package edu.pnu.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.pnu.domain.Favorites;
import edu.pnu.persistence.FavoriteRepository;

@Service
public class FavoriteService {

	 	@Autowired
	    private FavoriteRepository favoriteRepository;
	 	@Transactional
	    public void addFavorite(String username, String hospitalCode) {
	        Favorites favorite = new Favorites();
	        favorite.setUsername(username);
	        favorite.setHospitalCode(hospitalCode);
	       
	        List<String> oldList =favoriteRepository.findByUserId( username) ;
	        if (!oldList.contains(hospitalCode))
	        	favoriteRepository.save(favorite);
	    }
	    @Transactional
	    public void removeFavorite(String username, String hospitalCode) {
	        favoriteRepository.deleteByUsernameAndHospitalCode( username,hospitalCode);
	    }

	    public List<String> getFavorites(String username) {
	        return favoriteRepository.findByUserId( username);
	    }
	    
	    
	    
	   
	}
