package edu.pnu.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.pnu.domain.Member;
import edu.pnu.persistence.MemberRepository;



@Service
public class MemberService {
    @Autowired
    private  MemberRepository  memberRepo;
   
    public List<Member> getAllMembers() {
        return  memberRepo.findAll();
    }
 
    public Member getMemberById(String username) {
    	 return memberRepo.findById(username)
                 .orElseThrow(() -> new RuntimeException("Member not found"));
    }
    @Transactional
    public Member addMember(Member member) {
    	return memberRepo.save(member);
    	
    }
    @Transactional
    public Member  updateMember(Member member) {
    	Member updateMember = memberRepo.findById(member.getUsername())
                .orElseThrow(() -> new RuntimeException("Member not found"));
    	updateMember.setPassword(member.getPassword());
    	updateMember.setRole(member.getRole());
    	return memberRepo.save(updateMember);
    	
    	
    }
    @Transactional
    public  void  removeMember(String username) {
    	 memberRepo.deleteById(username);
    }
    
    public Member checkEmailExists(String email) {
        try {
            Member member = memberRepo.checkEmailExists(email);
            System.out.println("Member found: " + member); // 로그 메시지 추가
            return member;
        } catch (Exception e) {
            e.printStackTrace(); // 예외 메시지 확인
            throw e;
        }
    }
    public Member checkUsernameExists(String username) {
        try {
            Member member = memberRepo.checkUsernameExists( username);
            System.out.println("Member found: " + member); // 로그 메시지 추가
            return member;
        } catch (Exception e) {
            e.printStackTrace(); // 예외 메시지 확인
            throw e;
        }
    }
}
