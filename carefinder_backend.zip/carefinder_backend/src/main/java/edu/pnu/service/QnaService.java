package edu.pnu.service;


import java.sql.SQLException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import edu.pnu.domain.Member;
import edu.pnu.domain.Qna;
import edu.pnu.domain.QnaRe;
import edu.pnu.persistence.QnaReRepository;
import edu.pnu.persistence.QnaRepository;




//
@Service
public class QnaService {

  
    @Autowired
    private QnaRepository qnaRepo;
    
    @Autowired
    private QnaReRepository qnaReRepo;
    
    public List<Qna> getAllQnaList() throws SQLException {
       
    	return qnaRepo.findAll();
    }
   
    public Qna getQna(Long id) throws SQLException {
       
    	return qnaRepo.findById(id).get();
    }

    

    @Transactional
    public void insertQna(Qna qna) throws SQLException {
      
    	 qnaRepo.save(qna);
    }
    @Transactional
    public void updateQna(Member member,Qna qna, Long id) throws SQLException {
    
    	Qna updateQna= qnaRepo.findById(id).get();

        if (updateQna.getQnaId()!=null) {

            // 게시물 작성자와 요청한 사용자가 동일한지 확인
            if (updateQna.getMember().getUsername().equals(member.getUsername())) {
            	updateQna.setContent(qna.getContent());
            	updateQna.setTitle(qna.getTitle());
            	qnaRepo.save(updateQna);
               
            } 
        }
    }
    @Transactional
    public void deleteQna(Member member, Long id) throws SQLException {
      
    	Qna qna= qnaRepo.findById(id).get();

        if (qna.getQnaId()!=null) {

            // 게시물 작성자와 요청한 사용자가 동일한지 확인
            //if (qna.getMember().getUsername().equals(member.getUsername())) {
            	qnaReRepo.deleteByQnaId(id);
            	qnaRepo.delete(qna);
               
           // } 
        }
    }
    
    public List<QnaRe> getQnaRe( Long id) throws SQLException {
        
    	return qnaReRepo.findQnaRe(id);
    }
   
    @Transactional
    public void insertQnaRe(QnaRe qnaRe) throws SQLException {
    	
    	qnaReRepo.save(qnaRe);
    }
    
 public List<Object>  getMyQna(String  username) throws SQLException {
        
    	return qnaRepo.getMyQna( username);
    }
   

   
}