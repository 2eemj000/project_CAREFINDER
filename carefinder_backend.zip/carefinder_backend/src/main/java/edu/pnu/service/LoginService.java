package edu.pnu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import edu.pnu.domain.LoginRequest;
import edu.pnu.domain.Member;
import edu.pnu.persistence.MemberRepository;

@Service
public class LoginService {


    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    public boolean authenticate(LoginRequest loginRequest) {
        Member member = memberRepository.checkEmailExists(loginRequest.getEmail());
        
        
     
        if (member == null) {
            return false;
        }
        
        System.out.println("입력한 비밀번호: " + loginRequest.getPassword());
        System.out.println("저장된 암호화된 비밀번호: " + member.getPassword());
        
        // 입력한 비밀번호와 저장된 암호화된 비밀번호를 비교
        return passwordEncoder.matches(loginRequest.getPassword(), member.getPassword());
    }
    
   
    public Member findMemberByEmail(String email) {
        return memberRepository.checkEmailExists(email);
    }
}

