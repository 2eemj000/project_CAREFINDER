package edu.pnu.service;


import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.pnu.domain.Board;
import edu.pnu.domain.BoardRe;
import edu.pnu.domain.Member;
import edu.pnu.persistence.BoardReRepository;
import edu.pnu.persistence.BoardRepository;




//
@Service
public class BoardService {

  
    @Autowired
    private BoardRepository  boardRepo;
    @Autowired
    private BoardReRepository boardReRepo;
    
    public List<Board> getAllBoardList() throws SQLException {
       
    	return boardRepo.findAll();
    }
   
    public Board getBoard(Long id) throws SQLException {
       
    	return boardRepo.findById(id).get();
    }

    

    @Transactional
    public void insertBoard(Board board) throws SQLException {
      
    	boardRepo.save(board);
    }
    @Transactional
    public void updateBoard(Member member,Board board, Long id) throws SQLException {
    
    	Board updateboard= boardRepo.findById(id).get();

        if (updateboard.getBoardId()!=null) {

            // 게시물 작성자와 요청한 사용자가 동일한지 확인
            if (updateboard.getMember().getUsername().equals(member.getUsername())) {
            	if (board.getTitle()!=null && board.getContent()!=null) {
            	updateboard.setContent(board.getContent());
            	updateboard.setTitle(board.getTitle());
               	boardRepo.save(updateboard);
            	}
            	else if(board.getTitle()==null && board.getContent()!=null) {
            		updateboard.setContent(board.getContent());
                   	boardRepo.save(updateboard);
            	}
            	else if (board.getTitle()!=null && board.getContent()==null) {
            	 	updateboard.setTitle(board.getTitle());
                   	boardRepo.save(updateboard);
            	}
               
            } 
        }
    }
    @Transactional
    public void updateBoard(Board board) throws SQLException {
    
    	Board updateboard= boardRepo.findById(board.getBoardId()).get();

        if (updateboard.getBoardId()!=null) {

            // 게시물 작성자와 요청한 사용자가 동일한지 확인
            
            	updateboard.setCnt(board.getCnt());
      
               	boardRepo.save(updateboard);
               
            } 
        }
    
    
    @Transactional
    public void deleteBoard(Member member, Long id) throws SQLException {
      
    	Board board= boardRepo.findById(id).get();

        if (board.getBoardId()!=null) {

            // 게시물 작성자와 요청한 사용자가 동일한지 확인
            if (board.getMember().getUsername().equals(member.getUsername())) {
            	boardReRepo.deleteByBoardId(id);
                boardRepo.delete(board);
               
            } 
        }
    }
    
    
    public List<BoardRe> getBoardRe(Long id) throws SQLException {
        
    	return boardReRepo.findAllById(id);
    }
   
    @Transactional
    public void insertBoardRe(BoardRe boardRe) throws SQLException {
      
    	boardReRepo.save(boardRe);
    }

    
    
    public List<Object>  getMyBoard(String  username) throws SQLException {
        
    	return boardRepo. getMyBoard(username);
    }
    
    
   
}