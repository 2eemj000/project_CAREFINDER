package edu.pnu.controller;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.pnu.domain.Board;
import edu.pnu.domain.Member;
import edu.pnu.domain.Qna;
import edu.pnu.service.BoardService;
import edu.pnu.service.QnaService;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/checkSession")
@CrossOrigin(origins = "http://localhost:3000" , allowCredentials = "true")
public class SessionController {

//    @Autowired
//    private HttpSession session;
	@Autowired
	private BoardService boardService;
	@Autowired
	private QnaService qnaService;
    @GetMapping
    public ResponseEntity<?> checkSession(HttpSession session) {
        Member member = (Member) session.getAttribute("user");
        if (member != null) {
            return ResponseEntity.ok(member); // 로그인된 사용자 정보를 반환
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build(); // 로그인되지 않은 상태
        }
    }
    
    @GetMapping("/mypage")
    public ResponseEntity<?> getMyInfo(HttpSession session) throws SQLException {
        Member member = (Member) session.getAttribute("user");
        if (member != null) {
        	List<Object> blist =boardService.getMyBoard(member.getUsername());
        	List<Object> qlist=qnaService.getMyQna(member.getUsername());
        	
        	Map<String, List <Object>> response = new HashMap<>();
        	response.put("board", blist);
        	response.put("qna", qlist);
        	
            return ResponseEntity.ok(response); // 로그인된 사용자 정보를 반환
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build(); // 로그인되지 않은 상태
        }
    }
}