package edu.pnu.controller;



import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import edu.pnu.domain.LoginRequest;
import edu.pnu.domain.Member;
import edu.pnu.service.LoginService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@RestController
@RequestMapping("")
@CrossOrigin(origins = "http://localhost:3000")
public class  LoginController {

	 	@Autowired
	    private LoginService loginService;

	 	
	 	
	 	@GetMapping("/signin")
	 	public void redirectToReactLogin(HttpServletResponse response) throws IOException {
	 	        // 리액트 애플리케이션의 로그인 페이지 URL로 리다이렉트
	 	        response.sendRedirect("http://localhost:3000/find");
	 	}
	 	  
	 	  
	 	  
	 	@PostMapping("/signin")
	 	public ResponseEntity<Void> login(@RequestBody LoginRequest loginRequest, HttpServletRequest request) {
	 	    try {
	 	        boolean authenticated = loginService.authenticate(loginRequest);

	 	        if (authenticated) {
	 	            HttpSession session = request.getSession(true);
	 	            Member member = loginService.findMemberByEmail(loginRequest.getEmail());
	 	            session.setAttribute("user", member);
	 	            return ResponseEntity.ok().build();
	 	        } else {
	 	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
	 	        }
	 	    } catch (Exception e) {
	 	        // 로그에 예외를 기록하거나 디버깅을 위한 처리를 합니다.
	 	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	 	    }
	 	}
	 	@PostMapping("/signout")
	 	public ResponseEntity<Void> signout(HttpServletRequest request, HttpServletResponse response , @RequestParam(required = false) String googleToken) {
	 	    try {
	 	        // 웹 애플리케이션 세션 무효화
	 	        HttpSession session = request.getSession(false);
	 	        System.out.println("session"+session);
	 	        if (session != null) {
	 	            session.invalidate(); // 세션 무효화
	 	        }

	 	      
	 	       // 응답 헤더에 Cache-Control 추가
	 	        response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
	 	        response.setHeader("Cache-Control", "post-check=0, pre-check=0");
	 	        response.setHeader("Pragma", "no-cache");
	 	        
	 	        
	 	       // 구글 로그인 상태 확인 (세션 또는 쿠키에서 확인)
	 	        boolean isGoogleLoggedIn = checkIfGoogleLoggedIn(request);
	 	        if (isGoogleLoggedIn) {
	 	            // 구글 로그아웃 URL로 리다이렉션
	 	            String googleLogoutUrl = "https://accounts.google.com/Logout?continue=" + URLEncoder.encode("http://localhost:3000/find", "UTF-8");
	 	            response.sendRedirect(googleLogoutUrl);
	 	            Cookie[] cookies = request.getCookies();
		 	        if (cookies != null) {
		 	            for (Cookie cookie : cookies) {
		 	                if ("JSESSIONID".equals(cookie.getName())) {
		 	                    cookie.setValue(null);
		 	                    cookie.setPath("/");
		 	                    cookie.setMaxAge(0); // 쿠키 만료 설정
		 	                    response.addCookie(cookie);
		 	                }
		 	            }
		 	        }
	 	            return ResponseEntity.ok().build();
	 	        }
	 	        
	 	    // 클라이언트 측 쿠키도 무효화
	 	        Cookie[] cookies = request.getCookies();
	 	        if (cookies != null) {
	 	            for (Cookie cookie : cookies) {
	 	                if ("JSESSIONID".equals(cookie.getName())) {
	 	                    cookie.setValue(null);
	 	                    cookie.setPath("/");
	 	                    cookie.setMaxAge(0); // 쿠키 만료 설정
	 	                    response.addCookie(cookie);
	 	                }
	 	            }
	 	        }
	 	        
	 	        // 구글 로그아웃이 필요 없는 경우
	 	        return ResponseEntity.ok().build();
	 	    } catch (Exception e) {
	 	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	 	    }
	 	}

	 	private boolean checkIfGoogleLoggedIn(HttpServletRequest request) {
	 	    Cookie[] cookies = request.getCookies();
	 	    if (cookies != null) {
	 	        for (Cookie cookie : cookies) {
	 	            if ("googleLoggedIn".equals(cookie.getName())) {
	 	                return true;
	 	            }
	 	        }
	 	    }
	 	    return false;
	 	}
	 
	 	@GetMapping("/check-google-login")
	 	public ResponseEntity<Map<String, Boolean>> checkGoogleLogin(HttpServletRequest request) {
	 	    Cookie[] cookies = request.getCookies();
	 	    boolean isGoogleLoggedIn = false;

	 	    if (cookies != null) {
	 	        for (Cookie cookie : cookies) {
	 	            if ("googleLoggedIn".equals(cookie.getName())) {
	 	                isGoogleLoggedIn = "true".equals(cookie.getValue());
	 	                break;
	 	            }
	 	        }
	 	    }

	 	    Map<String, Boolean> response = new HashMap<>();
	 	    response.put("isLoggedInWithGoogle", isGoogleLoggedIn);

	 	    return ResponseEntity.ok(response);
	 	}

	    
	
}