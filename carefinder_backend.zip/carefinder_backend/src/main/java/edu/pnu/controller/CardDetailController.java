package edu.pnu.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import edu.pnu.domain.Information;
import edu.pnu.domain.Level;
import edu.pnu.service.InformationService;
import lombok.RequiredArgsConstructor;


@CrossOrigin(origins = "http://localhost:3000")
@RequiredArgsConstructor
@RestController
@RequestMapping("/find")
public class CardDetailController {
	 @Autowired
	    private InformationService informationService;

	    @GetMapping("/card/{cardId}")
	    public ResponseEntity<Map<String, List<Map<String, Object>>>>  getInformation  (@PathVariable String cardId) {

	        // 빈 값 체크 및 예외 처리
	        if (cardId == null ) {
	            return ResponseEntity.badRequest().body(null);
	        }

	        try {
	            // 병원 목록 가져오기

	          
	            String doctor = informationService.getDoctor(cardId);
	            String person = informationService.getPerson(cardId);
	            Information info =  informationService.getAllInfo(cardId);
	            System.out.println(doctor);
	            System.out.println(person);
	            System.out.println(info);
	            
	            
	            // 정보 목록이 비어있을 때 처리
	            if (doctor == null  && person== null&& info == null  ) {
	                System.out.println("리스트가 비었음");
	                return ResponseEntity.notFound().build();
	            }

	      

	            List<Map<String, Object>> infoList = new ArrayList<>();
	            Map<String, List<Map<String, Object>>> response = new HashMap<>();
	            
	    
	            Map<String, Object> tmp_infoList = new HashMap<>();
	           
	            tmp_infoList .put("id", info.getHospitalCode());
	            tmp_infoList .put("name", info.getHosName());
	            tmp_infoList .put("phone", info.getPhonenum());
	            tmp_infoList .put("address", info.getLocation()); 
	            tmp_infoList .put("locx",info.getLocx());
	            tmp_infoList.put("locy", info.getLocy());
                    
	            tmp_infoList.put("specialistInfo", doctor);
	            tmp_infoList .put("personInfo", person);
	            
	            infoList.add(tmp_infoList);
	                   
	            
	            response.put("1", infoList);
	            

	            return ResponseEntity.ok(response);
	            
	        } catch (Exception e) {
	            // 예외 처리 로직 추가
	            e.printStackTrace(); // 예외 상세 출력
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	    }
	 
}
