package edu.pnu.controller;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import edu.pnu.domain.Member;
import edu.pnu.service.MemberService;
import lombok.RequiredArgsConstructor;



@CrossOrigin(origins = "http://localhost:3000")
@RequiredArgsConstructor
@RestController
@RequestMapping("/signup")
public class MemberController {
	
    @Autowired
    private MemberService memberService;
    
    private final PasswordEncoder passwordEncoder;

    @GetMapping
    public ResponseEntity<List<Member>> getAllMembers() {
    	
        List<Member> members = memberService.getAllMembers();
        return ResponseEntity.ok(members);
    }

    @GetMapping("/{username}")
    public ResponseEntity<Member> getMemberById(@PathVariable String username) {
        Member member = memberService.getMemberById(username);
        if (member != null) {
            return ResponseEntity.ok(member);
        } else {
     
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Member> addMember(@RequestBody Member member) {
    	 // Encrypt the password
    	
    
          
    
    
        if (member.getPassword() != null) {
            String encodedPassword = passwordEncoder.encode(member.getPassword());
            member.setPassword(encodedPassword);
        }
    	
    	// Ensure that member has a role of 'member'
        if (member.getRole() == null || member.getRole().isEmpty()) {
            member.setRole("member");
        }

        Member addedMember = memberService.addMember(member);
        if (addedMember != null) {
            return ResponseEntity.status(201).body(addedMember);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
    @PutMapping
    public ResponseEntity<Member> updateMember(@RequestBody Member member) {
    	 Member updateMember = memberService.updateMember(member);
    	 if (updateMember != null) {
             return ResponseEntity.status(201).body(updateMember);
         } else {
             return ResponseEntity.badRequest().build();
         }
    }
    @GetMapping("/check-email")
    public ResponseEntity<Map<String, Boolean>> checkEmailExists(@RequestParam String email) {
        System.out.println("Received email: " + email); // 로그 메시지 추가
        try {
            Member member = memberService.checkEmailExists(email);
            Map<String, Boolean> response = new HashMap<>();
            
            if (member != null) {
                response.put("exists", true);
            } else {
                response.put("exists", false);
            }
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace(); // 로그로 예외 메시지 확인
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @GetMapping("/check-username")
    public ResponseEntity<Map<String, Boolean>> checkUsernameExists(@RequestParam String username) {
        System.out.println("Received username: " +username); // 로그 메시지 추가
        try {
            Member member = memberService.checkUsernameExists(username);
            Map<String, Boolean> response = new HashMap<>();
            
            if (member != null) {
                response.put("exists", true);
            } else {
                response.put("exists", false);
            }
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            e.printStackTrace(); // 로그로 예외 메시지 확인
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
}