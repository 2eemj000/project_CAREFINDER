package edu.pnu.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;

import edu.pnu.domain.Favorites;
import edu.pnu.domain.Level;
import edu.pnu.domain.Member;
import edu.pnu.service.FavoriteService;
import edu.pnu.service.InformationService;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("favorites")
@RequiredArgsConstructor
public class FavoriteController {
	@Autowired
    private FavoriteService favoriteService;

	 @Autowired
	    private InformationService informationService;

	
	
    @PostMapping("/add")
    public  ResponseEntity<Void> addFavorite(@SessionAttribute("user") Member member,@RequestParam String cardId) {
    	 try {
    	        favoriteService.addFavorite(member.getUsername(), cardId);
    	        return ResponseEntity.status(HttpStatus.CREATED).build();
    	    } catch (Exception e) {
    	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    	    }
    }

    @DeleteMapping("/remove")
    public  ResponseEntity<Void>  removeFavorite(@SessionAttribute("user") Member member,@RequestParam String cardId) {
        favoriteService.removeFavorite(member.getUsername(),  cardId);
    	return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<Map<String, List<Map<String, Object>>>> getFavorites(@SessionAttribute("user") Member member) {
    	 try {
    	List<String> favorites = favoriteService.getFavorites( member.getUsername());
        
        List<Map<String, Object>> hospitalList = new ArrayList<>();
        Map<String, List<Map<String, Object>>> response = new HashMap<>();

        for (String code : favorites) {
            Level tmpLevel = informationService.getHospitalListFromLevel(code);

            // Level 객체를 딕셔너리 형태로 변환
            if (tmpLevel != null && tmpLevel.getInformation() != null) {
                Map<String, Object> hospitalInfo = new HashMap<>();
                hospitalInfo.put("num", tmpLevel.getInformation().getNum());
                hospitalInfo.put("level", tmpLevel.getLevel());
                hospitalInfo.put("id", tmpLevel.getInformation().getHospitalCode());
                hospitalInfo.put("name", tmpLevel.getInformation().getHosName());
                hospitalInfo.put("sidoCode", tmpLevel.getInformation().getSidoCode());
                hospitalInfo.put("sidoCodeName", tmpLevel.getInformation().getSidoCodeName());
                hospitalInfo.put("sigunguCode", tmpLevel.getInformation().getSigunguCode());
                hospitalInfo.put("sigunguCodeName", tmpLevel.getInformation().getSigunguCodeName());
                hospitalInfo.put("address", tmpLevel.getInformation().getLocation());
                hospitalInfo.put("phone", tmpLevel.getInformation().getPhonenum());
                hospitalInfo.put("locx", tmpLevel.getInformation().getLocx());
                hospitalInfo.put("locy", tmpLevel.getInformation().getLocy());

                hospitalList.add(hospitalInfo);
            }
        }

        response.put("1", hospitalList);
        return ResponseEntity.ok(response);
        
    } catch (Exception e) {
        // 예외 처리 로직 추가
        e.printStackTrace(); // 예외 상세 출력
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    }
    
    
}
