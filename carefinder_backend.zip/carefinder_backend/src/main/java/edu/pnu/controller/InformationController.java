package edu.pnu.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import edu.pnu.domain.Doctor;
import edu.pnu.domain.Information;
import edu.pnu.domain.Level;
import edu.pnu.domain.Person;
import edu.pnu.domain.Sidosigungu;
import edu.pnu.service.InformationService;
import lombok.RequiredArgsConstructor;




@CrossOrigin(origins = "http://localhost:3000")
@RequiredArgsConstructor
@RestController
@RequestMapping("/find")
public class InformationController {

    @Autowired
    private InformationService informationService;

    @GetMapping("/list")
    public ResponseEntity<Map<String, List<Map<String, Object>>>> getInformation(
            @RequestParam String sido,
            @RequestParam String sigungu,
            @RequestParam(required = false) List<String> doctor,
            @RequestParam(required = false) List<String> person) {

        try {
            // 병원 목록 가져오기
            String finalSido = informationService.getlocation(sido);
            String finalSigungu = informationService.getlocation2(sigungu);
            System.out.println("시도명: " + finalSido);
            System.out.println("시군구코드: " + finalSigungu);

            List<String> codeList = informationService.getCodeList(finalSido, finalSigungu);
            System.out.println("코드 리스트: " + codeList);

            // Check if doctor and person are null or empty
            boolean hasDoctor = doctor != null && !doctor.isEmpty();
            boolean hasPerson = person != null && !person.isEmpty();
            List<String> informationList1;
            // Determine the appropriate query based on the presence of doctor and person
            
            if (hasDoctor && hasPerson) {
                System.out.println("Both doctor and person provided");
                // When both doctor and person are provided
                informationList1 = informationService.gethospitalListtFromDoctor(codeList, doctor);
                informationList1 = informationService.gethospitalListtFromPerson(informationList1, person);
            } else if (hasDoctor) {
                System.out.println("Doctor provided");
                // When only doctor is provided
                informationList1 = informationService.gethospitalListtFromDoctor(codeList, doctor);
            } else if (hasPerson) {
                System.out.println("Person provided");
                // When only person is provided
                informationList1 = informationService.gethospitalListtFromPerson(codeList, person);
            } else {
                System.out.println("Neither doctor nor person provided");
                // When neither doctor nor person is provided
                informationList1 = codeList;
            }

            // 정보 목록이 비어있을 때 처리
            if (informationList1 == null || informationList1.isEmpty()) {
                System.out.println("리스트가 비었음");
                return ResponseEntity.notFound().build();
            }

            List<Map<String, Object>> hospitalList = new ArrayList<>();
            Map<String, List<Map<String, Object>>> response = new HashMap<>();

            for (String code : informationList1) {
                System.out.println("공통코드: " + code);
                Level tmpLevel = informationService.getHospitalListFromLevel(code);

                // Level 객체를 딕셔너리 형태로 변환
                if (tmpLevel != null && tmpLevel.getInformation() != null) {
                    Map<String, Object> hospitalInfo = new HashMap<>();
                    hospitalInfo.put("num", tmpLevel.getInformation().getNum());
                    hospitalInfo.put("level", tmpLevel.getLevel());
                    hospitalInfo.put("id", tmpLevel.getInformation().getHospitalCode());
                    hospitalInfo.put("name", tmpLevel.getInformation().getHosName());
                    hospitalInfo.put("sidoCode", tmpLevel.getInformation().getSidoCode());
                    hospitalInfo.put("sidoCodeName", tmpLevel.getInformation().getSidoCodeName());
                    hospitalInfo.put("sigunguCode", tmpLevel.getInformation().getSigunguCode());
                    hospitalInfo.put("sigunguCodeName", tmpLevel.getInformation().getSigunguCodeName());
                    hospitalInfo.put("address", tmpLevel.getInformation().getLocation());
                    hospitalInfo.put("phone", tmpLevel.getInformation().getPhonenum());
                    hospitalInfo.put("locx", tmpLevel.getInformation().getLocx());
                    hospitalInfo.put("locy", tmpLevel.getInformation().getLocy());

                    hospitalList.add(hospitalInfo);
                }
            }

            response.put("1", hospitalList);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            // 예외 처리 로직 추가
            e.printStackTrace(); // 예외 상세 출력
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    
    @GetMapping("/regions")
    public ResponseEntity<List<Map<String, String>>> getLocation() {
        // 가정: informationService.getLocation() 메서드가 List<String[]>을 반환합니다.
        // 각 String[]은 ["01", "지"] 형식으로 지역 코드와 이름을 포함합니다.
        List<String[]> regionsList = informationService.getLocation();
        
        // List<String[]>을 List<Map<String, String>>으로 변환합니다.
        List<Map<String, String>> regionsMapList = new ArrayList<>();
        for (String[] region : regionsList) {
            Map<String, String> regionMap = new HashMap<>();
            if (region.length == 2) {
                regionMap.put("code", region[0]);
                regionMap.put("name", region[1]);
                regionsMapList.add(regionMap);
            }
        }
        
        return ResponseEntity.ok(regionsMapList);
    }
    @GetMapping("/subregions")
    public ResponseEntity<Map<String, List<Map<String, String>>>> getLocation(@RequestParam String region1) {
        List<String[]> regions;
        Sidosigungu regionName =null;

        try {
        	regionName = informationService.findSubRegionsCode(region1);
            regions = informationService.getLocation(regionName.getSidoname());
           

            if (regions == null ||  regionName  == null) {
            	  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }

           
            List<Map<String, String>> regionsMapList = new ArrayList<>();
            for (String[] region : regions) {
                if (region.length == 2) {
                    Map<String, String> regionMap = new HashMap<>();
                    regionMap.put("code", region[0]);
                    regionMap.put("name", region[1]);
                    regionsMapList.add(regionMap);
                } else {
                    // 로그를 남기거나 추가 처리를 합니다
                    System.out.println("Unexpected region array length: " + region.length);
                }
            }

            Map<String, List<Map<String, String>>> resultMap = new HashMap<>();
            resultMap.put( regionsMapList.get(0).get("code"), regionsMapList);

            return ResponseEntity.ok(resultMap);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}