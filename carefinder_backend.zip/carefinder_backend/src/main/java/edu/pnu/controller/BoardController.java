package edu.pnu.controller;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;

import edu.pnu.domain.Board;
import edu.pnu.domain.BoardRe;
//import edu.pnu.domain.BoardRe;
import edu.pnu.domain.Member;
//import edu.pnu.service.BoardReService;
import edu.pnu.service.BoardService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@CrossOrigin(origins = "http://localhost:3000")
@RequiredArgsConstructor
@RestController
@RequestMapping("/community")
public class BoardController {

	@Autowired
	private BoardService boardService;


	@GetMapping
	public ResponseEntity<List<Board>> getBoardList() {
		try {
			List<Board> boards = boardService.getAllBoardList();
			if (boards.isEmpty()) {
				return ResponseEntity.noContent().build();
			} else {
				return ResponseEntity.ok(boards);
			}
		} catch (SQLException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<Board> getBoard(@PathVariable Long id) {
		try {
			Board board = boardService.getBoard(id);
			
			if (board != null) {
				board.setCnt(board.getCnt() + 1);
		            
		            // 게시판을 업데이트합니다.
		        boardService.updateBoard(board);
				return ResponseEntity.ok(board);
			} else {
				return ResponseEntity.notFound().build();
			}
		} catch (SQLException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@PostMapping("/write")
	public ResponseEntity<Void> insertBoard(@SessionAttribute("user") Member member, @RequestBody Board board) {
		
		if  (member == null || member.getUsername() == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		try {
			board.setMember(member);
			board.setCreateDate(new Date());
			board.setCnt(0L);
			boardService.insertBoard(board);
			return ResponseEntity.status(HttpStatus.CREATED).build();
		} catch (SQLException e) {
			e.printStackTrace(); // 로그에 상세 오류를 기록합니다.
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<Void> updateBoard(@SessionAttribute("user") Member member, @PathVariable Long id,
			@RequestBody Board board) {
		if (member == null || member.getUsername() == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		try {

			boardService.updateBoard(member, board, id);
			return ResponseEntity.ok().build();
		} catch (SQLException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteBoard(@SessionAttribute("user") Member member, @PathVariable Long id) {
		if (member == null ||member.getUsername() == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		try {

			boardService.deleteBoard(member, id);
			return ResponseEntity.noContent().build();
		} catch (SQLException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	@GetMapping("reply/{id}")
	public ResponseEntity <List<BoardRe>> getBoardRe(@PathVariable Long id) {
		try {
			List<BoardRe> boardRe = boardService.getBoardRe(id);
			if ( boardRe !=null) {
				
				return ResponseEntity.ok( boardRe);
			} else {
				return ResponseEntity.notFound().build();
			}
		} catch (SQLException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@PostMapping("reply/write/{id}")
	public ResponseEntity<Void> insertBoardRe(@SessionAttribute("user") Member member,@PathVariable Long id, @RequestBody BoardRe boardRe) {
		if(member == null || member.getUsername() == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
		try {
			boardRe.setMember(member);
			boardRe.setCreateDate(new Date());
			boardRe.setBoard(boardService.getBoard(id));
			boardService.insertBoardRe(boardRe);
			return ResponseEntity.status(HttpStatus.CREATED).build();
		} catch (SQLException e) {
			e.printStackTrace(); // 로그에 상세 오류를 기록합니다.
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

}